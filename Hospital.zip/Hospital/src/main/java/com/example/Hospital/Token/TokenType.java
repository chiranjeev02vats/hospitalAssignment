package com.example.Hospital.Token;

public enum TokenType {
    BEARER
}
